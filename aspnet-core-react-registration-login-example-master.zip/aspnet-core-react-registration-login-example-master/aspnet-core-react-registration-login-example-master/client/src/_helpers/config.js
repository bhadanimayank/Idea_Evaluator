export const config = {
    apiUrl: 'http://localhost:56755'
};