﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Entities
{
    public class Idea
    {
        public int Id { get; set; }
        public string Idea_Name { get; set; }
        public string Description { get; set; }
        public int user1 { get; set; }
        public bool eval1 { get; set; }
        public int user2 { get; set; }
        public bool eval2 { get; set; }
        public int user3 { get; set; }
        public bool eval3 { get; set; }

    }
}
