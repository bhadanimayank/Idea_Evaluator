﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Entities;
using WebApi.Helpers;

namespace WebApi.Services
{
    public interface IIdeaService
    {
        Idea Create(Idea idea);
        void Assignment();
    }
    public class IdeaService : IIdeaService
    {
        private DataContext _context;

        public IdeaService(DataContext context)
        {
            _context = context;
        }
        public Idea Create(Idea idea)
        {
            _context.Ideas.Add(idea);
            _context.SaveChanges();

            return idea;
        }

        public void Assignment()
        {
            int count_Ideas = _context.Ideas.Count();
            var random = new Random();
            User judge;
            Idea idea;

            for (int i = 0; i < count_Ideas; i++)
            {
                bool check_1 = true;
                bool check_2 = true;
                bool check_3 = true;
                idea = _context.Ideas.ToList()[i];

                while (check_1)
                {
                    int index = random.Next(_context.Users.Count());
                    judge = _context.Users.ToList()[index];

                    if (judge.IdeaAssigned < 12)
                    { 
                        idea.user1 = judge.Id;
                        judge.IdeaAssigned = ++judge.IdeaAssigned;

                        var jud = _context.Users.Where(k => k.Id == judge.Id).SingleOrDefault();
                        jud = judge;
                        _context.Users.Update(jud);

                        var ide = _context.Ideas.Where(k => k.Id == idea.Id).SingleOrDefault();
                        ide = idea;
                        _context.Ideas.Update(ide);

                        _context.SaveChanges(true);
                        check_1 = false;
                    }
                }

                while (check_2)
                {
                    int index = random.Next(_context.Users.Count());
                    judge = _context.Users.ToList()[index];

                    if (judge.IdeaAssigned < 12 && idea.user1 != judge.Id)
                    {
                        idea.user2 = judge.Id;
                        judge.IdeaAssigned = ++judge.IdeaAssigned;

                        var jud = _context.Users.Where(k => k.Id == judge.Id).SingleOrDefault();
                        jud = judge;
                        _context.Users.Update(jud);

                        var ide = _context.Ideas.Where(k => k.Id == idea.Id).SingleOrDefault();
                        ide = idea;
                        _context.Ideas.Update(ide);

                        _context.SaveChanges(true);
                        check_2 = false;
                    }
                }

                while (check_3)
                {
                    int index = random.Next(_context.Users.Count());
                    judge = _context.Users.ToList()[index];

                    if (judge.IdeaAssigned < 12 && idea.user1 != judge.Id && idea.user2 != judge.Id)
                    {
                        idea.user3 = judge.Id;
                        judge.IdeaAssigned = ++judge.IdeaAssigned;

                        var jud = _context.Users.Where(k => k.Id == judge.Id).SingleOrDefault();
                        jud = judge;
                        _context.Users.Update(jud);

                        var ide = _context.Ideas.Where(k => k.Id == idea.Id).SingleOrDefault();
                        ide = idea;
                        _context.Ideas.Update(ide);

                        _context.SaveChanges(true);
                        check_3 = false;
                    }
                }

            }
        }
    }
}
